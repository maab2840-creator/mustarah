package com.mustarah.app

import android.Manifest
import androidx.fragment.app.FragmentActivity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.util.UUID

class MainActivity : FragmentActivity() {
    private lateinit var store: Store
    private var backAction: (() -> Unit)? = null
    private var current: (() -> Unit)? = null
    private var unlocked = false
    private var pendingMediaCallback: ((String) -> Unit)? = null
    private var recorder: MediaRecorder? = null
    private var recordingPath: String? = null
    private var player: MediaPlayer? = null
    private val ui = Handler(Looper.getMainLooper())

    private val pickPhoto = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri: Uri? -> handlePicked(uri, "jpg") }
    private val pickVideo = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri: Uri? -> handlePicked(uri, "mp4") }

    private fun handlePicked(uri: Uri?, ext: String) {
        if (uri == null) return
        val cb = pendingMediaCallback ?: return
        Thread {
            try {
                val dir = File(filesDir, "media"); dir.mkdirs()
                val out = File(dir, "${UUID.randomUUID()}.$ext")
                contentResolver.openInputStream(uri)?.use { input -> out.outputStream().use { o -> input.copyTo(o) } }
                ui.post { cb(out.absolutePath) }
            } catch (e: Exception) {
                ui.post { Toast.makeText(this, "تعذّر إضافة الملف: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this); C.set(store.theme); styleBars()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        Scheduler.rescheduleAll(this)
        if (store.hasLock && !unlocked) showLock() else { unlocked = true; showHome() }
    }

    override fun onResume() { super.onResume(); if (unlocked) current?.invoke() }

    @Suppress("DEPRECATION")
    override fun onBackPressed() { val b = backAction; if (b != null) b() else super.onBackPressed() }

    @Suppress("DEPRECATION")
    private fun styleBars() {
        window.statusBarColor = C.BG; window.navigationBarColor = C.BG
        val d = window.decorView; var f = d.systemUiVisibility
        f = if (C.idx == 1 || C.idx == 4) f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
        else f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        d.systemUiVisibility = f
    }

    // ---------------- القفل ----------------
    private fun showLock() {
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL; col.gravity = Gravity.CENTER
        col.setBackgroundColor(C.BG); col.setPadding(dp(28), dp(28), dp(28), dp(28)); col.layoutDirection = View.LAYOUT_DIRECTION_RTL
        col.addView(tv("🔒", 44f, C.PRIMARY, true, true))
        col.addView(tv("اليوميات الخاصة", 22f, C.TEXT, true, true))
        col.addView(tv("أدخل رمز الدخول", 14f, C.MUTED, false, true))
        val input = editField("ادخل الرمز")
        input.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        input.gravity = Gravity.CENTER; input.textSize = 26f
        col.addView(input)
        val err = tv("", 13f, C.WARN, false, true); col.addView(err)
        col.addView(btn("دخول") {
            if (store.pin.isNotEmpty() && input.text.toString() == store.pin) { unlocked = true; showHome() }
            else err.text = "الرمز غير صحيح"
        })
        if (store.biometricOn) col.addView(btn("استخدام البصمة", C.CARD, C.PRIMARY_DARK) { tryBiometric() })
        setContentView(col)
        backAction = { moveTaskToBack(true) }
        if (store.biometricOn) tryBiometric()
    }

    private fun tryBiometric() {
        val bm = BiometricManager.from(this)
        if (bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) != BiometricManager.BIOMETRIC_SUCCESS) return
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { unlocked = true; runOnUiThread { showHome() } }
        })
        val info = BiometricPrompt.PromptInfo.Builder().setTitle("مُستراح").setSubtitle("استخدم بصمتك للدخول").setNegativeButtonText("إلغاء").build()
        prompt.authenticate(info)
    }

    // ---------------- هيكل الصفحات ----------------
    private fun page(navSel: Int, back: (() -> Unit)?, title: String?): LinearLayout {
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(18), dp(20), dp(24))
        val sv = ScrollView(this); sv.addView(col)
        val root = LinearLayout(this); root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(C.BG); root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        if (navSel >= 0) root.addView(navBar(navSel))
        setContentView(root); backAction = back
        if (title != null) col.addView(header(title, if (navSel < 0) back else null))
        return col
    }

    private fun header(title: String, back: (() -> Unit)?): View {
        val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
        val arrow = TextView(this); arrow.text = if (back != null) "→" else ""; arrow.textSize = 26f
        arrow.setTextColor(C.PRIMARY_DARK); arrow.gravity = Gravity.CENTER; arrow.layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        if (back != null) arrow.setOnClickListener { back() }
        val t = tv(title, 22f, C.PRIMARY_DARK, true, true)
        t.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val sp = View(this); sp.layoutParams = LinearLayout.LayoutParams(dp(44), 1)
        row.addView(arrow); row.addView(t); row.addView(sp); return row
    }

    private fun navBar(sel: Int): View {
        val bar = LinearLayout(this); bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(C.CARD); bar.setPadding(dp(8), dp(6), dp(8), dp(6))
        val items = listOf("🏠" to "الرئيسية", "📔" to "يومياتي", "✅" to "مهامي", "🌱" to "عاداتي", "⚙️" to "الإعدادات")
        items.forEachIndexed { i, item ->
            val cell = LinearLayout(this); cell.orientation = LinearLayout.VERTICAL; cell.gravity = Gravity.CENTER
            cell.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            val a = TextView(this); a.text = item.first; a.textSize = 20f; a.gravity = Gravity.CENTER; a.alpha = if (i == sel) 1f else 0.5f
            val b = TextView(this); b.text = item.second; b.textSize = 11f; b.gravity = Gravity.CENTER
            b.setTextColor(if (i == sel) C.PRIMARY_DARK else C.MUTED); if (i == sel) b.setTypeface(b.typeface, Typeface.BOLD)
            cell.addView(a); cell.addView(b)
            cell.setOnClickListener { when (i) { 0 -> showHome(); 1 -> showDiaryGate(); 2 -> showTaskLists(); 3 -> showHabits(); else -> showSettings() } }
            bar.addView(cell)
        }
        return bar
    }

    private fun chip(text: String, selected: Boolean, onClick: () -> Unit): TextView {
        val c = TextView(this); c.text = text; c.textSize = 14f; c.gravity = Gravity.CENTER
        c.setPadding(dp(16), dp(8), dp(16), dp(8)); c.setTextColor(if (selected) C.ON_PRIMARY else C.TEXT)
        c.background = rounded(if (selected) C.PRIMARY else C.SOFT, dp(20).toFloat())
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT); lp.marginEnd = dp(8); lp.topMargin = dp(4); lp.bottomMargin = dp(4)
        c.layoutParams = lp; c.setOnClickListener { onClick() }; return c
    }

    private fun smallBtn(text: String, onClick: () -> Unit): TextView {
        val t = TextView(this); t.text = text; t.textSize = 14f; t.setTextColor(C.PRIMARY_DARK); t.gravity = Gravity.CENTER
        t.setPadding(dp(8), dp(10), dp(8), dp(10)); t.background = rounded(C.SOFT, dp(12).toFloat())
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); lp.marginStart = dp(4); lp.marginEnd = dp(4)
        t.layoutParams = lp; t.setOnClickListener { onClick() }; return t
    }

    private fun colorDot(color: Int, size: Int = 14): View {
        val v = View(this); v.background = ovalGrad(color, color)
        v.layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)); return v
    }

    private fun colorPicker(selected: Int, onPick: (Int) -> Unit): View {
        val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); lp.topMargin = dp(10)
        row.layoutParams = lp
        Palette.colors.forEachIndexed { i, c ->
            val dot = View(this)
            val bg = ovalGrad(c, c); if (i == selected) bg.setStroke(dp(3), C.TEXT)
            dot.background = bg
            val dlp = LinearLayout.LayoutParams(dp(32), dp(32)); dlp.marginEnd = dp(8)
            dot.layoutParams = dlp; dot.setOnClickListener { onPick(i) }
            row.addView(dot)
        }
        return row
    }

    private fun greeting(): String {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return when { h < 5 -> "ليلة سعيدة 🌙"; h < 12 -> "صباح الخير ☀️"; h < 17 -> "نهارك سعيد 🌿"; else -> "مساء الخير 🌙" }
    }
    private fun moodEmoji(m: Int) = listOf("😢", "😕", "😐", "😊", "😄").getOrElse(m - 1) { "😐" }
    private fun moodLabel(m: Int) = listOf("سيئ", "متوسط", "عادي", "جيد", "ممتاز").getOrElse(m - 1) { "عادي" }
    private fun fmtTime(m: Int) = String.format("%02d:%02d", m / 60, m % 60)

    private fun pickTime(initial: Int?, onPick: (Int) -> Unit) {
        val cal = java.util.Calendar.getInstance()
        val h0 = initial?.div(60) ?: cal.get(java.util.Calendar.HOUR_OF_DAY)
        val m0 = initial?.rem(60) ?: cal.get(java.util.Calendar.MINUTE)
        TimePickerDialog(this, { _, h, m -> onPick(h * 60 + m) }, h0, m0, true).show()
    }

    // ---------------- الرئيسية ----------------
    private fun showHome() {
        current = { showHome() }
        val col = page(0, null, null)
        col.addView(tv(greeting(), 26f, C.TEXT, true, true))
        col.addView(tv("كيف كان يومك اليوم؟", 14f, C.MUTED, false, true))

        val rev = store.review(store.today())
        val (done, total) = store.todayProgress()
        val pct = if (total == 0) 0 else done * 100 / total

        val top = card()
        val row1 = LinearLayout(this); row1.orientation = LinearLayout.HORIZONTAL
        row1.addView(tv(Fmt.human.format(java.util.Date()), 15f, C.MUTED).also { it.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
        if (rev != null) row1.addView(tv(moodEmoji(rev.mood) + " " + moodLabel(rev.mood), 15f, C.TEXT, true))
        top.addView(row1)
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 100; bar.progress = pct
        bar.progressTintList = android.content.res.ColorStateList.valueOf(C.PRIMARY)
        val blp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8)); blp.topMargin = dp(10); bar.layoutParams = blp
        top.addView(bar)
        top.addView(tv("$done / $total • $pct% تقدّم اليوم", 13f, C.MUTED))
        col.addView(top)

        col.addView(tv("وصول سريع", 15f, C.MUTED, false, true))
        val grid = LinearLayout(this); grid.orientation = LinearLayout.HORIZONTAL
        val glp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); glp.topMargin = dp(8)
        grid.layoutParams = glp
        fun quick(emoji: String, label: String, action: () -> Unit): View {
            val c = LinearLayout(this); c.orientation = LinearLayout.VERTICAL; c.gravity = Gravity.CENTER
            c.setPadding(dp(8), dp(14), dp(8), dp(14)); c.background = rounded(C.CARD, dp(16).toFloat())
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); lp.marginStart = dp(4); lp.marginEnd = dp(4)
            c.layoutParams = lp; c.addView(tv(emoji, 22f, C.TEXT, false, true)); c.addView(tv(label, 12f, C.TEXT, false, true))
            c.setOnClickListener { action() }; return c
        }
        grid.addView(quick("📔", "يومياتي") { showDiaryGate() })
        grid.addView(quick("✅", "مهامي") { showTaskLists() })
        grid.addView(quick("🌱", "عاداتي") { showHabits() })
        grid.addView(quick("⭐", "مراجعة اليوم") { showReview() })
        col.addView(grid)
        col.addView(btn("📊 إحصائيات الإنجاز", C.CARD, C.PRIMARY_DARK) { showStats() })
    }

    // ---------------- الإحصائيات ----------------
    private fun statBlock(col: LinearLayout, title: String, done: Int, total: Int) {
        val c = card()
        val pct = if (total == 0) 0 else done * 100 / total
        val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL
        row.addView(tv(title, 16f, C.TEXT, true).also { it.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
        row.addView(tv("$pct%", 18f, C.PRIMARY_DARK, true))
        c.addView(row)
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 100; bar.progress = pct; bar.progressTintList = android.content.res.ColorStateList.valueOf(C.PRIMARY)
        val blp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8)); blp.topMargin = dp(8); bar.layoutParams = blp
        c.addView(bar)
        c.addView(tv("$done / $total مكتملة", 13f, C.MUTED))
        col.addView(c)
    }

    private fun showStats() {
        current = { showStats() }
        val col = page(-1, { showHome() }, "إحصائيات الإنجاز")
        val (dd, dt) = store.dayCompletion(store.today())
        statBlock(col, "اليوم", dd, dt)
        val (wd, wt) = store.rangeCompletion(7)
        statBlock(col, "آخر 7 أيام", wd, wt)
        val (md, mt) = store.monthCompletion()
        statBlock(col, "هذا الشهر", md, mt)
    }

    // ---------------- اليوميات ----------------
    private fun showDiaryGate() {
        if (!store.hasLock) { showDiaryList(); return }
        current = { showDiaryGate() }
        val col = page(1, { showHome() }, null)
        col.addView(tv("🔒", 40f, C.PRIMARY, true, true))
        col.addView(tv("اليوميات الخاصة", 20f, C.TEXT, true, true))
        col.addView(btn("فتح اليوميات") { showDiaryList() })
    }

    private fun showDiaryList() {
        current = { showDiaryList() }
        val col = page(1, { showHome() }, "يومياتي")
        col.addView(btn("＋ إضافة يومية جديدة") { showDiaryAdd(null) })
        val list = store.diaryList()
        if (list.isEmpty()) col.addView(tv("لا توجد يوميات بعد.", 14f, C.MUTED, false, true))
        var lastDay = ""
        for (e in list) {
            if (e.dateKey != lastDay) { lastDay = e.dateKey; col.addView(tv(e.dateKey, 14f, C.MUTED, true)) }
            val c = card()
            c.addView(tv(Fmt.time.format(java.util.Date(e.time)), 12f, C.MUTED))
            if (e.text.isNotEmpty()) c.addView(tv(e.text, 16f, C.TEXT))
            if (e.photoPath != null) c.addView(photoThumb(e.photoPath!!))
            if (e.videoPath != null) c.addView(videoRow(e.videoPath!!))
            if (e.audioPath != null) c.addView(audioRow(e.audioPath!!))
            val actions = LinearLayout(this); actions.orientation = LinearLayout.HORIZONTAL
            val alp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); alp.topMargin = dp(8)
            actions.layoutParams = alp
            actions.addView(smallBtn("تعديل") { showDiaryAdd(e) })
            actions.addView(smallBtn("حذف") {
                AlertDialog.Builder(this).setMessage("حذف هذه اليومية؟")
                    .setPositiveButton("حذف") { _, _ -> val l = store.diaryList(); l.removeAll { it.id == e.id }; store.saveDiary(l); showDiaryList() }
                    .setNegativeButton("إلغاء", null).show()
            })
            c.addView(actions)
            col.addView(c)
        }
    }

    private fun photoThumb(path: String): View {
        val iv = ImageView(this)
        try { iv.setImageBitmap(android.graphics.BitmapFactory.decodeFile(path)) } catch (e: Exception) {}
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(160)); lp.topMargin = dp(8)
        iv.layoutParams = lp; iv.background = rounded(C.SOFT, dp(12).toFloat()); iv.clipToOutline = true
        return iv
    }

    private fun audioRow(path: String): View {
        val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(12), dp(10), dp(12), dp(10)); row.background = rounded(C.SOFT, dp(14).toFloat())
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); lp.topMargin = dp(8)
        row.layoutParams = lp
        row.addView(tv("🎙️ تسجيل صوتي", 15f, C.TEXT).also { it.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
        val play = tv("▶ تشغيل", 14f, C.PRIMARY_DARK, true)
        play.setOnClickListener { try { player?.release(); player = MediaPlayer().apply { setDataSource(path); prepare(); start() } } catch (e: Exception) { Toast.makeText(this, "تعذّر التشغيل", Toast.LENGTH_SHORT).show() } }
        row.addView(play); return row
    }

    private fun videoRow(path: String): View {
        val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(12), dp(10), dp(12), dp(10)); row.background = rounded(C.SOFT, dp(14).toFloat())
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); lp.topMargin = dp(8)
        row.layoutParams = lp
        row.addView(tv("🎬 فيديو", 15f, C.TEXT).also { it.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
        val play = tv("▶ تشغيل", 14f, C.PRIMARY_DARK, true)
        play.setOnClickListener {
            try {
                val uri = FileProvider.getUriForFile(this, "com.mustarah.app.fileprovider", File(path))
                val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(i)
            } catch (e: Exception) { Toast.makeText(this, "تعذّر فتح الفيديو", Toast.LENGTH_SHORT).show() }
        }
        row.addView(play); return row
    }

    private fun showDiaryAdd(edit: DiaryEntry?) {
        current = { showDiaryAdd(edit) }
        val col = page(-1, { showDiaryList() }, if (edit == null) "يومية جديدة" else "تعديل اليومية")
        var photoPath = edit?.photoPath; var audioPath = edit?.audioPath; var videoPath = edit?.videoPath
        val text = editField("اكتب ما يدور في ذهنك...", edit?.text ?: "", multiline = true).also { it.minLines = 5 }
        col.addView(text)

        val mediaBox = LinearLayout(this); mediaBox.orientation = LinearLayout.VERTICAL
        fun refreshMedia() {
            mediaBox.removeAllViews()
            photoPath?.let { mediaBox.addView(photoThumb(it)) }
            videoPath?.let { mediaBox.addView(videoRow(it)) }
            audioPath?.let { mediaBox.addView(audioRow(it)) }
        }
        refreshMedia(); col.addView(mediaBox)

        val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL
        val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); rlp.topMargin = dp(10)
        row.layoutParams = rlp
        row.addView(smallBtn("📷 صورة") { pendingMediaCallback = { p -> photoPath = p; refreshMedia() }; pickPhoto.launch("image/*") })
        row.addView(smallBtn("🎬 فيديو") { pendingMediaCallback = { p -> videoPath = p; refreshMedia() }; pickVideo.launch("video/*") })
        val recBtn = smallBtn("🎙️ تسجيل", {})
        recBtn.setOnClickListener {
            if (recorder == null) {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2); return@setOnClickListener
                }
                val dir = File(filesDir, "media"); dir.mkdirs()
                val out = File(dir, "${UUID.randomUUID()}.m4a"); recordingPath = out.absolutePath
                recorder = MediaRecorder().apply {
                    setAudioSource(MediaRecorder.AudioSource.MIC); setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                    setAudioEncoder(MediaRecorder.AudioEncoder.AAC); setOutputFile(out.absolutePath)
                    try { prepare(); start() } catch (e: Exception) {}
                }
                recBtn.text = "⏹ إيقاف"
            } else {
                try { recorder?.stop() } catch (e: Exception) {}
                recorder?.release(); recorder = null
                audioPath = recordingPath; recBtn.text = "🎙️ تسجيل"; refreshMedia()
            }
        }
        row.addView(recBtn)
        col.addView(row)

        col.addView(btn("حفظ") {
            val list = store.diaryList()
            if (edit == null) {
                list.add(0, DiaryEntry(UUID.randomUUID().toString(), store.today(), System.currentTimeMillis(), text.text.toString(), photoPath, audioPath, videoPath))
            } else {
                val idx = list.indexOfFirst { it.id == edit.id }
                if (idx >= 0) list[idx] = DiaryEntry(edit.id, edit.dateKey, edit.time, text.text.toString(), photoPath, audioPath, videoPath)
            }
            store.saveDiary(list); showDiaryList()
        })
    }

    // ---------------- قوائم المهام ----------------
    private fun showTaskLists() {
        current = { showTaskLists() }
        val col = page(2, { showHome() }, "مهامي")
        col.addView(btn("＋ قائمة جديدة") { addTaskListDialog(null) })
        val lists = store.taskLists()
        if (lists.isEmpty()) col.addView(tv("لا توجد قوائم بعد. أنشئي أول قائمة لك.", 14f, C.MUTED, false, true))
        val items = store.taskItems()
        for (l in lists) {
            val top = items.filter { it.listId == l.id && it.parentId == null }
            val done = top.count { it.done }
            val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(16), dp(16), dp(16), dp(16)); row.background = rounded(l.color.let { Palette.colors.getOrElse(it) { C.PRIMARY } }, dp(20).toFloat())
            val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); rlp.topMargin = dp(10)
            row.layoutParams = rlp
            val info = LinearLayout(this); info.orientation = LinearLayout.VERTICAL
            info.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            info.addView(tv(l.name, 18f, 0xFFFFFFFF.toInt(), true))
            info.addView(tv("$done / ${top.size} مكتملة", 13f, 0xE6FFFFFF.toInt()))
            row.addView(info)
            row.setOnClickListener { showTaskListDetail(l.id) }
            col.addView(row)
        }
    }

    private fun addTaskListDialog(edit: TaskList?) {
        var color = edit?.color ?: 0
        val box = LinearLayout(this); box.orientation = LinearLayout.VERTICAL; box.setPadding(dp(20), dp(10), dp(20), 0)
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val name = EditText(this); name.hint = "اسم القائمة"; name.setText(edit?.name ?: ""); name.setTextColor(C.TEXT); name.setHintTextColor(C.MUTED)
        box.addView(name)
        box.addView(tv("اللون", 13f, C.MUTED))
        lateinit var picker: View
        val holder = LinearLayout(this); holder.orientation = LinearLayout.VERTICAL
        fun refresh() { holder.removeAllViews(); picker = colorPicker(color) { c -> color = c; refresh() }; holder.addView(picker) }
        refresh(); box.addView(holder)
        val b = AlertDialog.Builder(this).setTitle(if (edit == null) "قائمة جديدة" else "تعديل القائمة").setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val n = name.text.toString().trim()
                if (n.isNotEmpty()) {
                    val l = store.taskLists()
                    if (edit == null) l.add(TaskList(UUID.randomUUID().toString(), n, color, l.size))
                    else { val idx = l.indexOfFirst { it.id == edit.id }; if (idx >= 0) l[idx] = TaskList(edit.id, n, color, edit.order) }
                    store.saveTaskLists(l)
                }
                showTaskLists()
            }.setNegativeButton("إلغاء", null)
        if (edit != null) b.setNeutralButton("حذف القائمة") { _, _ ->
            val l = store.taskLists(); l.removeAll { it.id == edit.id }; store.saveTaskLists(l)
            val its = store.taskItems(); its.removeAll { it.listId == edit.id }; store.saveTaskItems(its)
            showTaskLists()
        }
        b.show()
    }

    private fun itemRow(list: TaskList, item: TaskItem, indent: Boolean, refresh: () -> Unit): View {
        val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(if (indent) dp(32) else dp(4), dp(8), dp(4), dp(8))
        val cb = CheckBox(this)
        cb.isChecked = item.done
        cb.buttonTintList = android.content.res.ColorStateList.valueOf(Palette.colors.getOrElse(list.color) { C.PRIMARY })
        cb.setOnCheckedChangeListener { _, v ->
            val all = store.taskItems(); val idx = all.indexOfFirst { it.id == item.id }
            if (idx >= 0) { all[idx].done = v; store.saveTaskItems(all) }
            refresh()
        }
        val title = TextView(this); title.text = item.text; title.textSize = 16f; title.setTextColor(C.TEXT)
        if (item.done) title.paintFlags = title.paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
        val info = LinearLayout(this); info.orientation = LinearLayout.VERTICAL
        info.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        info.addView(title)
        if (item.timeMinutes != null) info.addView(tv("⏰ ${fmtTime(item.timeMinutes!!)}", 12f, C.MUTED))
        val del = TextView(this); del.text = "✕"; del.setTextColor(C.MUTED); del.textSize = 16f
        del.setPadding(dp(8), dp(4), dp(8), dp(4))
        del.setOnClickListener {
            val all = store.taskItems()
            all.removeAll { it.id == item.id || it.parentId == item.id }
            store.saveTaskItems(all); Scheduler.cancel(this, "task_${item.id}"); refresh()
        }
        row.addView(cb); row.addView(info); row.addView(del)
        return row
    }

    private fun showTaskListDetail(listId: String) {
        current = { showTaskListDetail(listId) }
        val list = store.taskLists().find { it.id == listId } ?: run { showTaskLists(); return }
        val col = page(-1, { showTaskLists() }, list.name)
        col.addView(smallBtn("✎ تعديل القائمة / اللون") { addTaskListDialog(list) }.also {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT); it.layoutParams = lp
        })
        col.addView(btn("＋ إضافة بند") { addItemDialog(listId, null) })
        val items = store.itemsOf(listId)
        val top = items.filter { it.parentId == null }
        if (top.isEmpty()) col.addView(tv("لا توجد بنود بعد.", 14f, C.MUTED, false, true))
        for (it0 in top) {
            col.addView(itemRow(list, it0, false) { showTaskListDetail(listId) })
            val subs = items.filter { it.parentId == it0.id }
            for (s in subs) col.addView(itemRow(list, s, true) { showTaskListDetail(listId) })
            col.addView(smallBtn("＋ بند فرعي تحت «${it0.text}»") { addItemDialog(listId, it0.id) }.also {
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT); lp.marginStart = dp(28); it.layoutParams = lp
            })
        }
    }

    private fun addItemDialog(listId: String, parentId: String?) {
        var minutes: Int? = null
        val box = LinearLayout(this); box.orientation = LinearLayout.VERTICAL; box.setPadding(dp(20), dp(10), dp(20), 0)
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val text = EditText(this); text.hint = "نص البند"; text.setTextColor(C.TEXT); text.setHintTextColor(C.MUTED)
        box.addView(text)
        val timeBtn = smallBtn("⏰ تذكير بوقت (اختياري)") {}
        timeBtn.setOnClickListener { pickTime(null) { m -> minutes = m; timeBtn.text = "⏰ ${fmtTime(m)}" } }
        box.addView(timeBtn)
        AlertDialog.Builder(this).setTitle(if (parentId == null) "بند جديد" else "بند فرعي جديد").setView(box)
            .setPositiveButton("إضافة") { _, _ ->
                val t = text.text.toString().trim()
                if (t.isNotEmpty()) {
                    val all = store.taskItems()
                    val order = all.count { it.listId == listId }
                    val item = TaskItem(UUID.randomUUID().toString(), listId, parentId, t, false, minutes, order)
                    all.add(item); store.saveTaskItems(all)
                    if (minutes != null) Scheduler.scheduleAt(this, "task_${item.id}", minutes!!, "✅ مهمة", t)
                }
                showTaskListDetail(listId)
            }.setNegativeButton("إلغاء", null).show()
    }

    // ---------------- العادات ----------------
    private fun showHabits() {
        current = { showHabits() }
        val col = page(3, { showHome() }, "عاداتي")
        col.addView(btn("＋ إضافة عادة") { addHabitDialog(null) })
        val habits = store.habits()
        if (habits.isEmpty()) col.addView(tv("لا توجد عادات بعد.", 14f, C.MUTED, false, true))
        val dayLabels = listOf("ح", "ن", "ث", "ر", "خ", "ج", "س")
        for (h in habits) {
            val tint = Palette.colors.getOrElse(h.color) { C.PRIMARY }
            val c = card()
            val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
            row.addView(colorDot(tint, 12).also { val l = LinearLayout.LayoutParams(dp(12), dp(12)); l.marginEnd = dp(8); it.layoutParams = l })
            row.addView(tv("${h.emoji}  ${h.name}", 17f, C.TEXT, true).also { it.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
            row.addView(smallBtn("✎") { addHabitDialog(h) }.also { val l = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT); it.layoutParams = l })
            c.addView(row)
            val sub = mutableListOf<String>()
            if (h.timeMinutes != null) sub.add("⏰ ${fmtTime(h.timeMinutes!!)}")
            sub.add(if (h.days.isEmpty()) "كل يوم" else h.days.sorted().joinToString("،") { dayLabels[it - 1] })
            if (h.timesPerDay > 1) sub.add("${h.timesPerDay} مرات/يوم")
            c.addView(tv(sub.joinToString("  •  "), 12f, C.MUTED))

            val days = LinearLayout(this); days.orientation = LinearLayout.HORIZONTAL
            val dlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); dlp.topMargin = dp(10)
            days.layoutParams = dlp
            for (off in 6 downTo 0) {
                val d = store.dayStr(-off)
                val active = store.habitActiveOn(h, d)
                val n = store.habitCount(h.id, d)
                val full = active && n >= h.timesPerDay
                val cell = TextView(this)
                cell.text = if (!active) "–" else if (h.timesPerDay > 1) "$n/${h.timesPerDay}" else if (full) "✓" else ""
                cell.textSize = 12f; cell.setTextColor(if (full) C.ON_PRIMARY else C.MUTED); cell.gravity = Gravity.CENTER
                cell.background = rounded(if (full) tint else C.SOFT, dp(10).toFloat())
                val clp = LinearLayout.LayoutParams(0, dp(36), 1f); clp.marginStart = dp(3); clp.marginEnd = dp(3)
                cell.layoutParams = clp
                if (off == 0 && active) cell.setOnClickListener {
                    val cur = store.habitCount(h.id, d); val next = if (cur >= h.timesPerDay) 0 else cur + 1
                    store.setHabitCount(h.id, d, next); showHabits()
                }
                days.addView(cell)
            }
            c.addView(days)
            col.addView(c)
        }
    }

    private fun addHabitDialog(edit: Habit?) {
        var color = edit?.color ?: 0
        var minutes = edit?.timeMinutes
        var days = (edit?.days ?: emptySet()).toMutableSet()
        var tpd = edit?.timesPerDay ?: 1
        val box = LinearLayout(this); box.orientation = LinearLayout.VERTICAL; box.setPadding(dp(20), dp(10), dp(20), 0)
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val name = EditText(this); name.hint = "اسم العادة"; name.setText(edit?.name ?: ""); name.setTextColor(C.TEXT); name.setHintTextColor(C.MUTED)
        val emoji = EditText(this); emoji.hint = "رمز تعبيري مثل 💧"; emoji.setText(edit?.emoji ?: ""); emoji.setTextColor(C.TEXT); emoji.setHintTextColor(C.MUTED)
        box.addView(name); box.addView(emoji)

        box.addView(tv("اللون", 13f, C.MUTED))
        val colorHolder = LinearLayout(this); colorHolder.orientation = LinearLayout.VERTICAL
        fun refreshColor() { colorHolder.removeAllViews(); colorHolder.addView(colorPicker(color) { c -> color = c; refreshColor() }) }
        refreshColor(); box.addView(colorHolder)

        box.addView(tv("أيام التذكير", 13f, C.MUTED))
        val dayLabels = listOf("ح", "ن", "ث", "ر", "خ", "ج", "س")
        val dayHolder = LinearLayout(this); dayHolder.orientation = LinearLayout.VERTICAL
        fun refreshDays() {
            dayHolder.removeAllViews()
            val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL
            for (i in 1..7) row.addView(chip(dayLabels[i - 1], i in days) { if (i in days) days.remove(i) else days.add(i); refreshDays() })
            dayHolder.addView(row)
        }
        refreshDays(); box.addView(dayHolder)
        box.addView(tv("(اتركيها فاضية = كل يوم)", 11f, C.MUTED))

        val tpdRow = LinearLayout(this); tpdRow.orientation = LinearLayout.HORIZONTAL; tpdRow.gravity = Gravity.CENTER_VERTICAL
        val tpdLabel = tv("عدد مرات اليوم: $tpd", 14f, C.TEXT)
        val minus = smallBtn("−") {}; val plus = smallBtn("＋") {}
        minus.setOnClickListener { if (tpd > 1) { tpd--; tpdLabel.text = "عدد مرات اليوم: $tpd" } }
        plus.setOnClickListener { if (tpd < 10) { tpd++; tpdLabel.text = "عدد مرات اليوم: $tpd" } }
        tpdRow.addView(minus); tpdRow.addView(tpdLabel.also { it.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) }); tpdRow.addView(plus)
        box.addView(tpdRow)

        val timeBtn = smallBtn(if (minutes != null) "⏰ ${fmtTime(minutes!!)}" else "⏰ تذكير بوقت (اختياري)") {}
        timeBtn.setOnClickListener { pickTime(minutes) { m -> minutes = m; timeBtn.text = "⏰ ${fmtTime(m)}" } }
        box.addView(timeBtn)

        val b = AlertDialog.Builder(this).setTitle(if (edit == null) "عادة جديدة" else "تعديل العادة").setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val n = name.text.toString().trim()
                if (n.isNotEmpty()) {
                    val l = store.habits()
                    val h = Habit(edit?.id ?: UUID.randomUUID().toString(), n, emoji.text.toString().ifEmpty { "🌱" }, color, tpd, minutes, days)
                    if (edit == null) l.add(h) else { val idx = l.indexOfFirst { it.id == edit.id }; if (idx >= 0) l[idx] = h }
                    store.saveHabits(l)
                    if (minutes != null) Scheduler.scheduleAt(this, "habit_${h.id}", minutes!!, "🌱 ${h.name}", "حان وقت ${h.name}", h.id)
                    else Scheduler.cancel(this, "habit_${h.id}")
                }
                showHabits()
            }.setNegativeButton("إلغاء", null)
        if (edit != null) b.setNeutralButton("حذف") { _, _ ->
            val l = store.habits(); l.removeAll { it.id == edit.id }; store.saveHabits(l); Scheduler.cancel(this, "habit_${edit.id}"); showHabits()
        }
        b.show()
    }

    // ---------------- مراجعة اليوم ----------------
    private fun showReview() {
        current = { showReview() }
        val col = page(-1, { showHome() }, "مراجعة اليوم")
        val existing = store.review(store.today())
        var mood = existing?.mood ?: 3; var stars = existing?.stars ?: 3
        val moodRow = LinearLayout(this); moodRow.orientation = LinearLayout.HORIZONTAL
        lateinit var refreshMood: () -> Unit
        refreshMood = {
            moodRow.removeAllViews()
            for (m in 1..5) {
                val e = TextView(this); e.text = moodEmoji(m); e.textSize = 26f; e.gravity = Gravity.CENTER
                e.alpha = if (m == mood) 1f else 0.4f
                e.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                e.setOnClickListener { mood = m; refreshMood() }
                moodRow.addView(e)
            }
        }
        col.addView(tv("مزاجك اليوم", 15f, C.MUTED)); refreshMood(); col.addView(moodRow)

        fun field(hint: String, value: String): EditText { col.addView(tv(hint, 14f, C.MUTED)); val e = editField(hint, value, multiline = true); col.addView(e); return e }
        val ach = field("ماذا أنجزت اليوم؟", existing?.achieved ?: "")
        val good = field("ما الشيء الجميل الذي حصل؟", existing?.good ?: "")
        val bad = field("ما الشيء الذي لم يعجبك؟", existing?.bad ?: "")
        val avoid = field("ما الخطأ الذي تريد ألا تكرره؟", existing?.avoidRepeat ?: "")
        val tom = field("ماذا تريد أن تفعل غدًا؟", existing?.tomorrow ?: "")

        val starRow = LinearLayout(this); starRow.orientation = LinearLayout.HORIZONTAL
        val srlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); srlp.topMargin = dp(10)
        starRow.layoutParams = srlp
        lateinit var refreshStars: () -> Unit
        refreshStars = {
            starRow.removeAllViews()
            for (s in 1..5) {
                val e = TextView(this); e.text = if (s <= stars) "★" else "☆"; e.textSize = 30f; e.setTextColor(C.GOLD); e.gravity = Gravity.CENTER
                e.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                e.setOnClickListener { stars = s; refreshStars() }
                starRow.addView(e)
            }
        }
        col.addView(tv("قيّم يومك", 14f, C.MUTED)); refreshStars(); col.addView(starRow)

        col.addView(btn("حفظ") {
            store.saveReview(Review(store.today(), mood, ach.text.toString(), good.text.toString(), bad.text.toString(), avoid.text.toString(), tom.text.toString(), stars))
            showHome()
        })
    }

    // ---------------- الإعدادات ----------------
    private fun showSettings() {
        current = { showSettings() }
        val col = page(4, { showHome() }, "الإعدادات")
        col.addView(tv("المظهر", 16f, C.PRIMARY_DARK, true))
        val themeRow = LinearLayout(this); themeRow.orientation = LinearLayout.HORIZONTAL
        val trlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); trlp.topMargin = dp(8)
        themeRow.layoutParams = trlp
        C.NAMES.forEachIndexed { i, n -> themeRow.addView(chip(n, i == store.theme) { store.theme = i; C.set(i); styleBars(); showSettings() }) }
        col.addView(themeRow)

        col.addView(tv("الحماية", 16f, C.PRIMARY_DARK, true))
        col.addView(btn(if (store.pin.isEmpty()) "تعيين رمز قفل" else "تغيير رمز القفل", C.CARD, C.PRIMARY_DARK) { setPinDialog() })
        val bioAvail = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
        if (bioAvail) {
            val sw = android.widget.Switch(this); sw.text = "استخدام البصمة لفتح اليوميات"; sw.isChecked = store.biometricOn
            sw.setTextColor(C.TEXT); sw.setOnCheckedChangeListener { _, v -> store.biometricOn = v }
            val c = card(); c.addView(sw); col.addView(c)
        }
        col.addView(btn("📊 إحصائيات الإنجاز", C.CARD, C.PRIMARY_DARK) { showStats() })
        col.addView(tv("هذا التطبيق يعمل بدون إنترنت، وكل بياناتك محفوظة على جهازك فقط.", 13f, C.MUTED))
    }

    private fun setPinDialog() {
        val input = EditText(this); input.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        input.hint = "رمز من 4 أرقام"; input.setTextColor(C.TEXT); input.setHintTextColor(C.MUTED)
        AlertDialog.Builder(this).setTitle("رمز القفل").setView(input)
            .setPositiveButton("حفظ") { _, _ -> val v = input.text.toString(); if (v.length >= 4) store.pin = v; showSettings() }
            .setNegativeButton("إلغاء", null)
            .setNeutralButton("إزالة القفل") { _, _ -> store.pin = ""; store.biometricOn = false; showSettings() }
            .show()
    }
}
