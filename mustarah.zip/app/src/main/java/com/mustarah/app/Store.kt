package com.mustarah.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class DiaryEntry(
    var id: String, var dateKey: String, var time: Long,
    var text: String, var photoPath: String?, var audioPath: String?
)

data class Task(
    var id: String, var title: String, var priority: Int, // 0 low,1 med,2 high
    var timeMinutes: Int?, var repeatDaily: Boolean, var dateKey: String, var done: Boolean
)

data class Habit(var id: String, var name: String, var emoji: String)

data class Review(
    var dateKey: String, var mood: Int, // 1..5
    var achieved: String, var good: String, var bad: String, var avoidRepeat: String, var tomorrow: String,
    var stars: Int
)

object Fmt {
    val day = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val human = SimpleDateFormat("d MMMM yyyy", Locale("ar"))
    val time = SimpleDateFormat("hh:mm a", Locale("ar"))
}

class Store(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("mustarah", Context.MODE_PRIVATE)

    fun today(): String = Fmt.day.format(Date())
    fun dayStr(offset: Int): String { val c = Calendar.getInstance(); c.add(Calendar.DAY_OF_YEAR, offset); return Fmt.day.format(c.time) }

    var theme: Int get() = p.getInt("theme", 0); set(v) = p.edit().putInt("theme", v).apply()

    // ---------- القفل ----------
    var pin: String get() = p.getString("pin", "") ?: ""; set(v) = p.edit().putString("pin", v).apply()
    var biometricOn: Boolean get() = p.getBoolean("bio", false); set(v) = p.edit().putBoolean("bio", v).apply()
    val hasLock: Boolean get() = pin.isNotEmpty() || biometricOn

    // ---------- اليوميات ----------
    fun diaryList(): MutableList<DiaryEntry> {
        val out = mutableListOf<DiaryEntry>()
        try {
            val arr = JSONArray(p.getString("diary", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(DiaryEntry(o.getString("id"), o.getString("d"), o.getLong("t"), o.getString("x"),
                    o.optString("p", "").ifEmpty { null }, o.optString("a", "").ifEmpty { null }))
            }
        } catch (e: Exception) {}
        return out.sortedByDescending { it.time }.toMutableList()
    }

    fun saveDiary(list: List<DiaryEntry>) {
        val arr = JSONArray()
        for (e in list) arr.put(JSONObject().put("id", e.id).put("d", e.dateKey).put("t", e.time)
            .put("x", e.text).put("p", e.photoPath ?: "").put("a", e.audioPath ?: ""))
        p.edit().putString("diary", arr.toString()).apply()
    }

    // ---------- المهام ----------
    fun tasksList(): MutableList<Task> {
        val out = mutableListOf<Task>()
        try {
            val arr = JSONArray(p.getString("tasks", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Task(o.getString("id"), o.getString("t"), o.getInt("pr"),
                    if (o.has("m") && !o.isNull("m")) o.getInt("m") else null,
                    o.getBoolean("rep"), o.getString("d"), o.getBoolean("done")))
            }
        } catch (e: Exception) {}
        return out
    }

    fun saveTasks(list: List<Task>) {
        val arr = JSONArray()
        for (t in list) arr.put(JSONObject().put("id", t.id).put("t", t.title).put("pr", t.priority)
            .put("m", t.timeMinutes).put("rep", t.repeatDaily).put("d", t.dateKey).put("done", t.done))
        p.edit().putString("tasks", arr.toString()).apply()
    }

    fun tasksForToday(): MutableList<Task> {
        val all = tasksList(); val t = today()
        val todays = all.filter { it.dateKey == t }.toMutableList()
        // ولّد نسخة اليوم من المهام المتكررة إن لم تكن موجودة بعد
        val recurringTitles = all.filter { it.repeatDaily && it.dateKey != t }
            .groupBy { it.title }.values.map { it.first() }
        var changed = false
        for (r in recurringTitles) {
            if (todays.none { it.title == r.title && it.repeatDaily }) {
                val n = Task(java.util.UUID.randomUUID().toString(), r.title, r.priority, r.timeMinutes, true, t, false)
                all.add(n); todays.add(n); changed = true
            }
        }
        if (changed) saveTasks(all)
        return todays
    }

    // ---------- العادات ----------
    fun habits(): MutableList<Habit> {
        val out = mutableListOf<Habit>()
        try {
            val arr = JSONArray(p.getString("habits", "[]"))
            for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); out.add(Habit(o.getString("id"), o.getString("n"), o.getString("e"))) }
        } catch (e: Exception) {}
        return out
    }
    fun saveHabits(list: List<Habit>) {
        val arr = JSONArray(); for (h in list) arr.put(JSONObject().put("id", h.id).put("n", h.name).put("e", h.emoji))
        p.edit().putString("habits", arr.toString()).apply()
    }
    fun habitDone(habitId: String, day: String): Boolean = p.getBoolean("hb_${habitId}_$day", false)
    fun setHabitDone(habitId: String, day: String, v: Boolean) = p.edit().putBoolean("hb_${habitId}_$day", v).apply()

    // ---------- مراجعة اليوم ----------
    fun review(day: String): Review? {
        val s = p.getString("rev_$day", null) ?: return null
        return try {
            val o = JSONObject(s)
            Review(day, o.getInt("mood"), o.getString("ach"), o.getString("good"), o.getString("bad"), o.getString("avoid"), o.getString("tom"), o.getInt("stars"))
        } catch (e: Exception) { null }
    }
    fun saveReview(r: Review) {
        val o = JSONObject().put("mood", r.mood).put("ach", r.achieved).put("good", r.good)
            .put("bad", r.bad).put("avoid", r.avoidRepeat).put("tom", r.tomorrow).put("stars", r.stars)
        p.edit().putString("rev_${r.dateKey}", o.toString()).apply()
    }

    fun todayProgress(): Pair<Int, Int> { val l = tasksForToday(); return l.count { it.done } to l.size }
}
