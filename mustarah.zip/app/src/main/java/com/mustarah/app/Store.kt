package com.mustarah.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class DiaryEntry(
    var id: String, var dateKey: String, var time: Long,
    var text: String, var photoPath: String?, var audioPath: String?, var videoPath: String?
)

data class TaskList(var id: String, var name: String, var color: Int, var order: Int)

data class TaskItem(
    var id: String, var listId: String, var parentId: String?, var text: String,
    var done: Boolean, var timeMinutes: Int?, var order: Int
)

data class Habit(
    var id: String, var name: String, var emoji: String, var color: Int,
    var timesPerDay: Int, var timeMinutes: Int?, var days: Set<Int> // 1..7, 1=Sunday؛ فاضية = كل يوم
)

data class Review(
    var dateKey: String, var mood: Int,
    var achieved: String, var good: String, var bad: String, var avoidRepeat: String, var tomorrow: String,
    var stars: Int
)

object Fmt {
    val day = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val human = SimpleDateFormat("d MMMM yyyy", Locale("ar"))
    val time = SimpleDateFormat("hh:mm a", Locale("ar"))
}

class Store(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("mustarah", Context.MODE_PRIVATE)

    fun today(): String = Fmt.day.format(Date())
    fun dayStr(offset: Int): String { val c = Calendar.getInstance(); c.add(Calendar.DAY_OF_YEAR, offset); return Fmt.day.format(c.time) }
    private fun weekdayOf(dateKey: String): Int {
        val c = Calendar.getInstance()
        try { c.time = Fmt.day.parse(dateKey) ?: Date() } catch (e: Exception) {}
        return c.get(Calendar.DAY_OF_WEEK) // 1..7, الأحد = 1
    }

    var theme: Int get() = p.getInt("theme", 0); set(v) = p.edit().putInt("theme", v).apply()

    // ---------- القفل ----------
    var pin: String get() = p.getString("pin", "") ?: ""; set(v) = p.edit().putString("pin", v).apply()
    var biometricOn: Boolean get() = p.getBoolean("bio", false); set(v) = p.edit().putBoolean("bio", v).apply()
    val hasLock: Boolean get() = pin.isNotEmpty() || biometricOn

    // ---------- اليوميات ----------
    fun diaryList(): MutableList<DiaryEntry> {
        val out = mutableListOf<DiaryEntry>()
        try {
            val arr = JSONArray(p.getString("diary", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(DiaryEntry(o.getString("id"), o.getString("d"), o.getLong("t"), o.getString("x"),
                    o.optString("p", "").ifEmpty { null }, o.optString("a", "").ifEmpty { null },
                    o.optString("v", "").ifEmpty { null }))
            }
        } catch (e: Exception) {}
        return out.sortedByDescending { it.time }.toMutableList()
    }
    fun saveDiary(list: List<DiaryEntry>) {
        val arr = JSONArray()
        for (e in list) arr.put(JSONObject().put("id", e.id).put("d", e.dateKey).put("t", e.time)
            .put("x", e.text).put("p", e.photoPath ?: "").put("a", e.audioPath ?: "").put("v", e.videoPath ?: ""))
        p.edit().putString("diary", arr.toString()).apply()
    }

    // ---------- قوائم المهام ----------
    fun taskLists(): MutableList<TaskList> {
        val out = mutableListOf<TaskList>()
        try {
            val arr = JSONArray(p.getString("tasklists", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(TaskList(o.getString("id"), o.getString("n"), o.getInt("c"), o.optInt("o", i)))
            }
        } catch (e: Exception) {}
        return out.sortedBy { it.order }.toMutableList()
    }
    fun saveTaskLists(l: List<TaskList>) {
        val arr = JSONArray(); for (x in l) arr.put(JSONObject().put("id", x.id).put("n", x.name).put("c", x.color).put("o", x.order))
        p.edit().putString("tasklists", arr.toString()).apply()
    }

    fun taskItems(): MutableList<TaskItem> {
        val out = mutableListOf<TaskItem>()
        try {
            val arr = JSONArray(p.getString("taskitems", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(TaskItem(o.getString("id"), o.getString("lid"),
                    o.optString("pid", "").ifEmpty { null }, o.getString("t"), o.getBoolean("done"),
                    if (o.has("m") && !o.isNull("m")) o.getInt("m") else null, o.optInt("o", i)))
            }
        } catch (e: Exception) {}
        return out
    }
    fun saveTaskItems(l: List<TaskItem>) {
        val arr = JSONArray()
        for (x in l) arr.put(JSONObject().put("id", x.id).put("lid", x.listId).put("pid", x.parentId ?: "")
            .put("t", x.text).put("done", x.done).put("m", x.timeMinutes).put("o", x.order))
        p.edit().putString("taskitems", arr.toString()).apply()
    }
    fun itemsOf(listId: String): List<TaskItem> = taskItems().filter { it.listId == listId }.sortedBy { it.order }

    // ---------- العادات ----------
    fun habits(): MutableList<Habit> {
        val out = mutableListOf<Habit>()
        try {
            val arr = JSONArray(p.getString("habits", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val daysArr = o.optJSONArray("days")
                val days = if (daysArr != null) (0 until daysArr.length()).map { daysArr.getInt(it) }.toSet() else emptySet()
                out.add(Habit(o.getString("id"), o.getString("n"), o.getString("e"), o.optInt("c", 0),
                    o.optInt("tpd", 1), if (o.has("m") && !o.isNull("m")) o.getInt("m") else null, days))
            }
        } catch (e: Exception) {}
        return out
    }
    fun saveHabits(list: List<Habit>) {
        val arr = JSONArray()
        for (h in list) {
            val daysArr = JSONArray(); for (d in h.days) daysArr.put(d)
            arr.put(JSONObject().put("id", h.id).put("n", h.name).put("e", h.emoji).put("c", h.color)
                .put("tpd", h.timesPerDay).put("m", h.timeMinutes).put("days", daysArr))
        }
        p.edit().putString("habits", arr.toString()).apply()
    }
    /** العادة نشطة في هذا اليوم؟ قائمة أيام فاضية تعني كل الأيام. */
    fun habitActiveOn(h: Habit, day: String): Boolean = h.days.isEmpty() || weekdayOf(day) in h.days
    fun habitCount(habitId: String, day: String): Int = p.getInt("hb_${habitId}_$day", 0)
    fun setHabitCount(habitId: String, day: String, v: Int) = p.edit().putInt("hb_${habitId}_$day", v).apply()

    // ---------- مراجعة اليوم ----------
    fun review(day: String): Review? {
        val s = p.getString("rev_$day", null) ?: return null
        return try {
            val o = JSONObject(s)
            Review(day, o.getInt("mood"), o.getString("ach"), o.getString("good"), o.getString("bad"), o.getString("avoid"), o.getString("tom"), o.getInt("stars"))
        } catch (e: Exception) { null }
    }
    fun saveReview(r: Review) {
        val o = JSONObject().put("mood", r.mood).put("ach", r.achieved).put("good", r.good)
            .put("bad", r.bad).put("avoid", r.avoidRepeat).put("tom", r.tomorrow).put("stars", r.stars)
        p.edit().putString("rev_${r.dateKey}", o.toString()).apply()
    }

    // ---------- تقدّم وإحصائيات ----------
    /** إنجاز يوم واحد: المهام تُحتسب فقط لليوم الحالي (لا تاريخ مُستقبلي لها)، والعادات حسب نشاطها في ذلك اليوم. */
    fun dayCompletion(day: String): Pair<Int, Int> {
        var done = 0; var total = 0
        if (day == today()) {
            val items = taskItems().filter { it.parentId == null }
            total += items.size; done += items.count { it.done }
        }
        val hs = habits().filter { habitActiveOn(it, day) }
        total += hs.size; done += hs.count { habitCount(it.id, day) >= it.timesPerDay }
        return done to total
    }

    fun rangeCompletion(days: Int): Pair<Int, Int> {
        var done = 0; var total = 0
        for (off in 0 until days) {
            val (d, t) = dayCompletion(dayStr(-off)); done += d; total += t
        }
        return done to total
    }

    fun monthCompletion(): Pair<Int, Int> {
        val c = Calendar.getInstance(); val dayOfMonth = c.get(Calendar.DAY_OF_MONTH)
        return rangeCompletion(dayOfMonth)
    }

    fun todayProgress(): Pair<Int, Int> = dayCompletion(today())
}
