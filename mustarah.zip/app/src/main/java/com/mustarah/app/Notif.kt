package com.mustarah.app

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import java.util.Calendar

object Notif {
    private const val CH = "mustarah"
    fun show(ctx: Context, id: Int, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "مُستراح", NotificationManager.IMPORTANCE_HIGH))
        val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(ctx, id, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(ctx, CH).setContentTitle(title).setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentIntent(pi).setAutoCancel(true).build()
        nm.notify(id, n)
    }
}

/** جدولة تذكير يومي لمهمة أو عادة. habitId: إن وُجد، يُتحقق أن العادة نشطة في هذا اليوم قبل الإشعار. */
object Scheduler {
    fun scheduleAt(ctx: Context, key: String, minutes: Int, title: String, body: String, habitId: String? = null) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, minutes / 60); cal.set(Calendar.MINUTE, minutes % 60)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
        val i = Intent(ctx, AlarmReceiver::class.java).putExtra("title", title).putExtra("body", body)
            .putExtra("key", key).putExtra("minutes", minutes).putExtra("habitId", habitId)
        val pi = PendingIntent.getBroadcast(ctx, key.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }

    fun cancel(ctx: Context, key: String) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val i = Intent(ctx, AlarmReceiver::class.java)
        val pi = PendingIntent.getBroadcast(ctx, key.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        am.cancel(pi)
    }

    fun rescheduleAll(ctx: Context) {
        val s = Store(ctx)
        for (t in s.taskItems()) if (!t.done && t.timeMinutes != null) scheduleAt(ctx, "task_${t.id}", t.timeMinutes!!, "✅ مهمة", t.text)
        for (h in s.habits()) if (h.timeMinutes != null) scheduleAt(ctx, "habit_${h.id}", h.timeMinutes!!, "🌱 ${h.name}", "حان وقت ${h.name}", h.id)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "تذكير"
        val body = intent.getStringExtra("body") ?: ""
        val key = intent.getStringExtra("key") ?: title
        val minutes = intent.getIntExtra("minutes", 0)
        val habitId = intent.getStringExtra("habitId")
        val s = Store(ctx)
        var skip = false
        if (habitId != null) {
            val h = s.habits().find { it.id == habitId }
            if (h == null || !s.habitActiveOn(h, s.today())) skip = true
        }
        if (!skip) Notif.show(ctx, key.hashCode(), title, body)
        // أعيدي الجدولة لليوم التالي
        Scheduler.scheduleAt(ctx, key, minutes, title, body, habitId)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) { Scheduler.rescheduleAll(ctx) }
}
